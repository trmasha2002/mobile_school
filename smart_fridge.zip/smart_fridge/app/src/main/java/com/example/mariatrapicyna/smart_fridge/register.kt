package com.example.mariatrapicyna.smart_fridge

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class register : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
    }
}
